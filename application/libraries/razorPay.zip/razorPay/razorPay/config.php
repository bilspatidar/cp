<?php


$keyId = 'rzp_test_GraRHmkcZ1ZkY4';//rzp_test_GraRHmkcZ1ZkY4
$keySecret = 'VLHsdRU9qq8yCOAUT5qjRMZv';//VLHsdRU9qq8yCOAUT5qjRMZv
$MerchantID ='Ein7Y61n9nG1kV';

$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);

